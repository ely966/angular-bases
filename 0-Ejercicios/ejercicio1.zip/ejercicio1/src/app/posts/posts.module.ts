import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ListComponent } from './components/list/list.component';
import { PostComponent } from './components/post/post.component';
import { HomeComponent } from './pages/home/home.component';

@NgModule({
  declarations: [HomeComponent, ListComponent, PostComponent],
  imports: [CommonModule],
  exports: [HomeComponent],
})
export class PostsModule {}
