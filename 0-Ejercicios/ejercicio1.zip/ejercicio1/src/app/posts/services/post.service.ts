import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { Post } from '../interfaces/post.interface';

@Injectable({
  providedIn: 'root',
})
export class PostService {
  //Guardar los post
  public posts: Post[] = [];
  private url: string = 'https://jsonplaceholder.typicode.com/todos';

  constructor(private httpClient: HttpClient) {
    console.log('iniciando servicio');
  }

  //_------------------------

  //Recoger datos de la api

  getPost(): Observable<Post[]> {
    return this.httpClient.get<Post[]>(this.url).pipe(
      tap((postRecibidos) => (this.posts = postRecibidos))
      //catchError ((error) =>  )
    );
  }

  getPostsList(): Post[] {
    console.log(this.posts);
    return this.posts;
  }
}
