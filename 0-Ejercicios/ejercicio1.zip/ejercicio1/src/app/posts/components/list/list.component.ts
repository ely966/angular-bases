import { Component, Input } from '@angular/core';
import { Post } from '../../interfaces/post.interface';
import { PostStoreService } from '../../services/post-store.service';

@Component({
  selector: 'post-list',
  templateUrl: './list.component.html',
  styleUrl: './list.component.css',
})
export class ListComponent {
  @Input() postList: Post[] | null = [];

  constructor(private postStoreServi: PostStoreService) {}
  posts$ = this.postStoreServi.posts$;
}
